"""
Timeseries API
"""

# flake8: noqa:F401

from pandas.tseries.frequencies import infer_freq
import pandas.tseries.offsets as offsets
